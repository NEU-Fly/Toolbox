function [U,B,feas] = CBF_QP(obj, x, u_d)
global Obstacle_Position SIZE;
if nargin < 3
    u_d = zeros(obj.udim, 1);
end

lambda = obj.params.cbf.rate;
Umin = obj.params.u_min;
Umax = obj.params.u_max;
Udim = obj.udim;

for i = 1:SIZE
    B{i,1} = obj.cbf{i}(x,Obstacle_Position(obj.params.dime*i-2:obj.params.dime*i));
    LfB{i,1} = obj.lf_cbf{i}(x,Obstacle_Position(obj.params.dime*i-2:obj.params.dime*i));
    LgB{i,1} = obj.lg_cbf{i}(x,Obstacle_Position(obj.params.dime*i-2:obj.params.dime*i));
end

%% QP���
u = sdpvar(obj.udim,1);  % ���߱���
Constraints = [];        % Լ��
for i = 1:SIZE           % CBFԼ��
    Constraints = [Constraints; cell2mat(LfB(i,1))+...
        cell2mat(LgB(i,1))*u + lambda*cell2mat(B(i,1)) >= 0];
end
Constraints = [Constraints; Umin <= u <= Umax];% ��������Լ��
%% �ɱ�����
H = obj.params.weight.input * eye(obj.udim);
Objective = 0.5*((u-u_d)'*H*(u-u_d));
Options = sdpsettings('verbose',0,'solver','quadprog');
sol = solvesdp(Constraints,Objective,Options);

if sol.problem == 0
    U = value(u);
    feas = 1;
else
    feas = 0;
    disp('QP���ɽ�');
end
end
function [U, delta, V, feas] = CLF_QP(obj, x, u_d)
global Target_State;
if nargin < 3
    u_d = zeros(obj.udim, 1);
end

gamma = obj.params.clf.rate;
Umin = obj.params.u_min;
Umax = obj.params.u_max;
p = obj.params.weight.delta_slack;
Udim = obj.udim;

V = obj.clf(x,Target_State);
LfV = obj.lf_clf(x,Target_State);
LgV = obj.lg_clf(x,Target_State);

%% QP���
u = sdpvar(obj.udim,1); % ���߱���
delta = sdpvar(1,1);    % �ɳڱ���

%% Լ��
Constraints = [];
Constraints = [Constraints; LfV + LgV*u + gamma*V <= delta];% CLFԼ��
Constraints = [Constraints; Umin <= u <= Umax];    % ��������Լ��
%% �ɱ�����
H = obj.params.weight.input * eye(obj.udim);
Objective = 0.5*((u-u_d)'*H*(u-u_d)) + p*(delta)^2;
Options = sdpsettings('verbose',0,'solver','quadprog');
sol = solvesdp(Constraints,Objective,Options);

if sol.problem == 0
    U = value(u);
    delta = value(delta);
    feas = 1;
else
    feas = 0;
    disp('QP���ɽ�');
end
end
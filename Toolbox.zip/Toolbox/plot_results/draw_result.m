global SIZE % �ϰ������
figure('Name','Result','position',[300,200,600,470]);
h=axes();
axis equal;
view(-45,30);
LIM = 6;
set(h,'LooseInset',get(h,'TightInset'),'NextPlot','add','Xgrid','on','Ygrid','on','Zgrid','on',...
    'Xlim',[-LIM, LIM],'Ylim',[-LIM, LIM],'Zlim',[-2, 5],'Xtick',-LIM:1:LIM,'Ytick',-LIM:1:LIM,'Ztick',-2:1:5);
xlabel('$x(m)$','interpret','latex','fontsize',12);
ylabel('$y(m)$','interpret','latex','fontsize',12);
zlabel('$z(m)$','interpret','latex','fontsize',12);
% �ϰ���
for i = 1:SIZE
    [x,y,z] = sphere(50);  
    h_circle(i) = surf(0*x, 0*y, 0*z); %#ok<*SAGROW>
    set(h_circle(i),'EdgeColor',[1 0 0],'FaceColor',[1 0 0]); 
end
obstacle.r = params.r_o;
% ��ʼλ��
p1=plot3(h,x0(1),x0(2),x0(3),'Marker','s','MarkerSize',10,'MarkerEdgeColor','k','MarkerFaceColor','k');
% �ο��켣
p2=plot3(h,Xd,Yd,Zd,'b--','LineWidth',2);
% Ŀ��λ��
p3=plot3(h,Xd(1),Yd(1),Zd(1));
set(p3,'Marker','p','MarkerSize',10,'MarkerEdgeColor','k','MarkerFaceColor','k');
k=10; % �ӿ���ʾ�ٶ�
for i =1:k:size(xs(:,1),1)
    pause(0.001);
    for k =1:SIZE
        obstacle.x = params.p_o(3*k-2,i);
        obstacle.y = params.p_o(3*k-1,i);
        obstacle.z = params.p_o(3*k,i);       
        % �����ϰ���λ��
        set(h_circle(k),'Xdata',obstacle.r*x+(obstacle.x),'Ydata',obstacle.r*y+(obstacle.y),'Zdata',obstacle.r*z+(obstacle.z))      
    end
    set(p3,'XData',Xd(i),'YData',Yd(i),'ZData',Zd(i)); % ����Ŀ��λ��
    p4=plot3(h,xs(1:k:i, 1), xs(1:k:i, 2),xs(1:k:i, 3),'k-','LineWidth',2); 
end
% plot(h,xs(:, 1), xs(:, 2),'k-','LineWidth',2); % ʵ�ʹ켣
% legend([p1 p3 p2 p4],'��ʼλ��','Ŀ��λ��','�ο��켣','״̬�켣');

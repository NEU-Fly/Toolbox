global SIZE % �ϰ������
figure('Name','Result','position',[300,200,800,400]);
tiledlayout(2,2,'TileSpacing','none','Padding','none');

nexttile(1,[2 1]);
h=gca;
axis equal;
view(-46,54);
LIM = 6;
set(h,'LooseInset',get(h,'TightInset'),'NextPlot','add','Xgrid','on','Ygrid','on','Zgrid','on',...
    'Xlim',[-LIM, LIM],'Ylim',[-LIM, LIM],'Zlim',[-2, 6],'Xtick',-LIM:2:LIM,'Ytick',-LIM:2:LIM,'Ztick',-2:2:6);
xlabel('$x(m)$','interpret','latex','fontsize',12);
ylabel('$y(m)$','interpret','latex','fontsize',12);
zlabel('$z(m)$','interpret','latex','fontsize',12);
title('ϵͳ���й켣');
% �ϰ���
for i = 1:SIZE
    [x,y,z] = sphere(50);  
    h_circle(i) = surf(0*x, 0*y, 0*z); %#ok<*SAGROW>
    set(h_circle(i),'EdgeColor',[1 0 0],'FaceColor',[1 0 0]); 
end
obstacle.r = params.r_o;
% ��ʼλ��
p1=plot3(h,x0(1),x0(2),x0(3),'Marker','s','MarkerSize',10,'MarkerEdgeColor','k','MarkerFaceColor','k');
% �ο��켣
p2=plot3(h,Xd(1),Yd(1),Zd(1),'b--','LineWidth',2);
% Ŀ��λ��
p3=plot3(h,Xd(1),Yd(1),Zd(1));
set(p3,'Marker','p','MarkerSize',10,'MarkerEdgeColor','b','MarkerFaceColor','b');
p5=plot3(h,x0(1),x0(1),x0(1));
set(p5,'Marker','o','MarkerSize',8,'MarkerEdgeColor','k','MarkerFaceColor','k');


nexttile(2);
dis = zeros(size(xs,1)-1,4);

for i=1:size(xs,1)-1
    for j=1:4
      dis(i,j) = norm(xs(i,1:3)'-params.p_o(3*j-2:3*j,i))-params.r_o;
    end
end

xlabel(gca,'$t(s)$','interpret','latex','fontsize',12);
ylabel(gca,'$d(m)$','interpret','latex','fontsize',12);
title('ϵͳ���ϰ���֮��ľ���');
set(gca,'XGrid','on','YGrid','on','box','on','ylim',[-2 10],'xlim',[0 sim_t]);


nexttile(4);
for i=1:size(xs,1)-1
    e(i)=norm(xs(i,1:3)-[Xd(i) Yd(i) Zd(i)]);
end

plot(gca,ts(1), e(1),'-','LineWidth',2);
xlabel('$t(s)$','interpret','latex','fontsize',12);
ylabel('$e(m)$','interpret','latex','fontsize',12);
title('�������');
set(gca,'box','on','Xgrid','on','ygrid','on','xlim',[0 sim_t],'ylim',[-2 6],'ytick',[-2:2:6]);


myvideo = VideoWriter('C:\Users\HTF\Desktop\��Ƶ\ʵ��1.avi');   % ������һ��avi�ļ�
myvideo.FrameRate = 120;                % ����֡Ƶ��
open(myvideo);                         % ��ʱƵ

for i =1:10:size(xs(:,1),1)
    for k =1:SIZE
        obstacle.x = params.p_o(3*k-2,i);
        obstacle.y = params.p_o(3*k-1,i);
        obstacle.z = params.p_o(3*k,i);       
        % �����ϰ���λ��
        set(h_circle(k),'Xdata',obstacle.r*x+(obstacle.x),'Ydata',obstacle.r*y+(obstacle.y),'Zdata',obstacle.r*z+(obstacle.z))      
    end
    set(p2,'XData',Xd(1:i),'YData',Yd(1:i),'ZData',Zd(1:i)); % ����Ŀ��λ��
    set(p3,'XData',Xd(i),'YData',Yd(i),'ZData',Zd(i)); % ����Ŀ��λ��
    set(p5,'XData',xs(i,1),'YData',xs(i,2),'ZData',xs(i,3)); % ����Ŀ��λ��
    p4=plot3(h,xs(1:k:i, 1), xs(1:k:i, 2),xs(1:k:i, 3),'k-','LineWidth',2); 
 
    nexttile(2);
    hold on;
    plot(gca,ts(1:i),dis(1:i,1),'-','LineWidth',2,'color','#0072BD');
    plot(gca,ts(1:i),dis(1:i,2),'--','LineWidth',2,'color','#D95319');
    plot(gca,ts(1:i),dis(1:i,3),'-.','LineWidth',2,'color','#7E2F8E');
    plot(gca,ts(1:i),dis(1:i,4),':','LineWidth',2,'color','#77AC30');
    hold off;
    
    nexttile(4);
    hold on;
    plot(ts(1:i), e(1:i),'-','linewidth',2,'color','#A2142F');
    hold off;
    
    % ������Ƶ
    drawnow limitrate                   % ���ٻ���
    frame = getframe(gcf);              % ץȡ��ͼ����ͼƬ
    im = frame2im(frame);               % ת����ʽ
    writeVideo(myvideo,im);             % д����Ƶ��
end

    close(myvideo);                     % �ر�avi�ļ�
% plot(h,xs(:, 1), xs(:, 2),'k-','LineWidth',2); % ʵ�ʹ켣
% legend([p1 p3 p2 p4],'��ʼλ��','Ŀ��λ��','�ο��켣','״̬�켣');

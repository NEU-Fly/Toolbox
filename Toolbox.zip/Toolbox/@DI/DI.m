

% �̳�ControlAffineSystem��
classdef DI < ControlAffineSystem
    methods
        function [x, f, g , pos, obs] = defineSystem(obj, params)
            syms p_x p_y p_z v_x v_y v_z;  % ״̬����
            syms pos_x pos_y pos_z;        % Ŀ��λ��
            syms o_x o_y o_z;              % �ϰ���λ��
            x = [p_x; p_y; p_z; v_x; v_y; v_z];
            pos = [pos_x; pos_y; pos_z];
            obs = [o_x; o_y; o_z];
            A = zeros(6); A(1, 4) = 1;
            A(2, 5) = 1;  A(3, 6) = 1;
            B = [0 0 0; 0 0 0; 0 0 0; 1 0 0; 0 1 0; 0 0 1];
            f = A * x;  g = B;
        end
		
        % ��дdefineClf
        function clf = defineCLF(obj, params, symbolic_state, pos)
            x = symbolic_state;
            A = zeros(6); A(1, 4) = 1;
            A(2, 5) = 1;  A(3, 6) = 1;
            B = [0 0 0; 0 0 0; 0 0 0; 1 0 0; 0 1 0; 0 0 1];
            Q = eye(size(A)); R = eye(size(B,2));
            [~,P] = lqr(A,B,Q,R);  % LQR
            e = x - [pos(1); pos(2); pos(3); 0; 0; 0];
            clf = e' * P * e;        
        end
		
        % ��дdefineCbf
        function cbf = defineCBF(~, params, symbolic_state,obs)
            global SIZE        % �ϰ������        
            x = symbolic_state;% ״̬
            r_o = params.r_o;  % �ϰ���뾶
            for i = 1:SIZE
                if size(r_o,1)==1
                    r(i) = r_o;
                end
                
                distance=(x(1)-obs(1))^2+(x(2)-obs(2))^2+...
				         (x(3)-obs(3))^2-r(i)^2;
                     
                derivDistance=2*(x(1)-obs(1))*x(4)+...
				              2*(x(2)-obs(2))*x(5)+...
							  2*(x(3)-obs(3))*x(6);
                          
                del = 1*exp(-0.1*distance+0.1);
                
                cbf(i,1) = derivDistance + distance - del; 
            end
        end 
    end
end

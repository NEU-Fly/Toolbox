classdef Car < CtrlAffineSys
methods
    function [x, f, g] = defineSystem(~, params)
        syms p_x p_y phi;  % �������״̬����
        x = [p_x; p_y; phi];

        f = [params.v*cos(x(3));
             params.v*sin(x(3));
              0];
        g = [0; 0; 1];
    end
    
    function clf = defineClf(~, params, symbolic_state)
        clf = [];               
    end
    
    function cbf = defineCbf(~, params, symbolic_state)
        x = symbolic_state;
        p_o = params.p_o; 
        r_o = params.r_o; 
        distance = (x(1) - p_o(1))^2 + (x(2) - p_o(2))^2 - r_o^2;
        derivDistance = 2*(x(1)-p_o(1))*params.v*cos(x(3)) + 2*(x(2)-p_o(2))*params.v*sin(x(3));
        cbf = derivDistance + params.cbf_gamma * distance;% - 2*exp(-distance+1);
    end



end
end

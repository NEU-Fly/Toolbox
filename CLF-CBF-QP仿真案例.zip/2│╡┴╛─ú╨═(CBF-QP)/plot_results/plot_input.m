clc;
figure('name','Input','position',[300 100 600 150]);
tiledlayout(1,1,'TileSpacing','none','Padding','none');
nexttile;
plot(ts(1:end-1), us(:,1),'-','LineWidth',2);
xlabel('$t(s)$','interpret','latex','fontsize',10);
ylabel('$\omega(rad/s)$','interpret','latex','fontsize',10);
set(gca,'box','on','Xgrid','on','ygrid','on','xtick',0:1:sim_t,'yTickLabel',num2str(get(gca,'yTick')','%.1f'));
clc;
figure('Name','State','position',[300 100 600 200]);
tiledlayout(2,1,'TileSpacing','none','Padding','none');
nexttile;
hold on;
plot(ts, xs(:,1),'-','LineWidth',2);
plot(ts, xs(:,2),'--','LineWidth',2);
ylabel('$p(m)$','interpret','latex','fontsize',10)
legend({'$x$','$y$'},'location','northeast','fontsize',10,'Interpreter','latex');
set(gca,'box','on','Xgrid','on','ygrid','on','xticklabel',[],'yTickLabel',num2str(get(gca,'yTick')','%.1f'));

nexttile;
plot(ts, xs(:, 3),'-','LineWidth',2)
xlabel('$t(s)$','interpret','latex','fontsize',10)
ylabel('$\theta(rad)$','interpret','latex','fontsize',10)
set(gca,'box','on','Xgrid','on','ygrid','on','xtick',0:1:sim_t,'yTickLabel',num2str(get(gca,'yTick')','%.1f'));
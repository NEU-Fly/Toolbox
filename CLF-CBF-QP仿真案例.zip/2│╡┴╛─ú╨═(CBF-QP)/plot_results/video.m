clc;
figure('Name','Result','position',[500,300,800,400]);

tiledlayout(2,2,'TileSpacing','none','Padding','none');
nexttile(1,[2 1]);
h1=gca;
axis equal;
lim=3;
set(h1,'LooseInset',get(h1,'TightInset'),'NextPlot','add','box','on','Xgrid','on','ygrid','on',...
    'xlim',[-lim, lim],'ylim',[-lim, lim],'xtick',-lim:1:lim,'ytick',-lim:1:lim);
xlabel(h1,'$x(m)$','interpret','latex','fontsize',12)
ylabel(h1,'$y(m)$','interpret','latex','fontsize',12)

% ��ʼλ��
p1=plot(h1,x0(1),x0(2),'Marker','s','MarkerSize',10,'MarkerEdgeColor','k','MarkerFaceColor','k');
title('��������');
% �ϰ���
obstacle.x = params.p_o(1);
obstacle.y = params.p_o(2);
obstacle.r = params.r_o;
p3=rectangle(h1,'Position',[obstacle.x-obstacle.r,obstacle.y-obstacle.r,...
          2*obstacle.r,2*obstacle.r],'Curvature',[1,1],'LineWidth',2,...
          'EdgeColor',[1 0 0],'FaceColor',[1 0 0]); % ����һ�������Σ�������������Ϊ1
l1=line(h1,0,0,'Color',[0 0.4470 0.7410],'LineStyle','-','Marker','.','markersize',2,'LineWidth',2);
l2=line(h1,0,0,'Color',[0 0.4470 0.7410],'LineStyle','-','Marker','.','markersize',2,'LineWidth',2);
l3=line(h1,0,0,'Color',[0 0.4470 0.7410],'LineStyle','-','Marker','.','markersize',2,'LineWidth',2);
l4=line(h1,0,0,'Color',[0 0.4470 0.7410],'LineStyle','-','Marker','.','markersize',2,'LineWidth',2);
h_patch=patch(h1,[0 0 0 0],[0 0 0 0],[0 0.4470 0.7410]);

l11=line(h1,0,0,'Color','k','LineStyle','-','LineWidth',6);
l22=line(h1,0,0,'Color','k','LineStyle','-','LineWidth',6);
l33=line(h1,0,0,'Color','k','LineStyle','-','LineWidth',6);
l44=line(h1,0,0,'Color','k','LineStyle','-','LineWidth',6);

text1 = text(h1);
set(text1,'Color','red','Position',[0.5 -1.5],'FontSize',14);


nexttile(2);
for k=1:size(xs,1)
   d(k) = norm(xs(k,1:2))-1;  
end

plot(ts(1),d(1),'b.');
title('ϵͳ���ϰ���֮��ľ���');
xlabel('$t(s)$','interpret','latex','fontsize',12)
ylabel('$d(m)$','interpret','latex','fontsize',12)
set(gca,'ylim',[0 3],'xlim',[0 sim_t],'box','on','Xgrid','on','ygrid','on','xtick',0:1:sim_t);

nexttile(4);
plot(ts(1), hs(1,1),'b.');
title('CBF');
xlabel('$t(s)$','interpret','latex','fontsize',12);
ylabel('$h$','interpret','latex','fontsize',12);
set(gca,'ylim',[-2 10],'xlim',[0 sim_t],'xtick',[0:1:sim_t],'box','on','Xgrid','on','ygrid','on');

myvideo = VideoWriter('.\����ģ��.avi');     % ������һ��avi�ļ�
myvideo.FrameRate = 25;                      % ����֡Ƶ��
open(myvideo);                               % ��ʱƵ

for i=1:2:size(xs(:,1),1)

    set(text1,'String',['T: ',num2str(ts(i),'%0.0f\n'),'s']);

    pos = xs(i,1:2)';
    phi = xs(i,3);
    R = [cos(phi) -sin(phi);... 
         sin(phi) cos(phi)];

    wHb = [R pos; 0 0  1];
    body=[-0.3 -0.3  0.3  0.3  -0.25 -0.15 0.15  0.25 -0.25 -0.15 0.15 0.25;
          -0.2  0.2  0.2  -0.2  0.2    0.2   0.2  0.2 -0.2   -0.2  -0.2 -0.2;
            1    1    1   1      1     1     1    1    1      1     1    1];
    world = wHb * body; 
    car_atti = world(1:2, :);  
    p3=plot(h1,xs(1:i, 1), xs(1:i, 2),'k-','LineWidth',2);

    set(l1,'XData',[car_atti(1,1) car_atti(1,2)],'YData',[car_atti(2,1) car_atti(2,2)]);
    set(l2,'XData',[car_atti(1,2) car_atti(1,3)],'YData',[car_atti(2,2) car_atti(2,3)]);
    set(l3,'XData',[car_atti(1,3) car_atti(1,4)],'YData',[car_atti(2,3) car_atti(2,4)]);
    set(l4,'XData',[car_atti(1,4) car_atti(1,1)],'YData',[car_atti(2,4) car_atti(2,1)]);
    set(h_patch,'Xdata',[car_atti(1,1:4)],'Ydata',[car_atti(2,1:4)]);
    set(l11,'XData',[car_atti(1,5) car_atti(1,6)],'YData',[car_atti(2,5) car_atti(2,6)]);
    set(l22,'XData',[car_atti(1,7) car_atti(1,8)],'YData',[car_atti(2,7) car_atti(2,8)]);
    set(l33,'XData',[car_atti(1,9) car_atti(1,10)],'YData',[car_atti(2,9) car_atti(2,10)]);
    set(l44,'XData',[car_atti(1,11) car_atti(1,12)],'YData',[car_atti(2,11) car_atti(2,12)]);
    
    nexttile(2);
    hold on;
    plot(ts(1:i),d(1:i),'b-','linewidth',2);
    hold off;
    
    nexttile(4);
    % CBF
    hold on
    plot(gca,ts(1:i), hs(1:i,1),'b-','linewidth',2);
    hold off
    
    % ������Ƶ
    drawnow limitrate                   % ���ٻ���
    frame = getframe(gcf);              % ץȡ��ͼ����ͼƬ
    im = frame2im(frame);               % ת����ʽ
    writeVideo(myvideo,im);             % д����Ƶ��
end

close(myvideo);                     % �ر�avi�ļ�

% plot(h,xs(:, 1), xs(:, 2),'k-','LineWidth',2);
% legend([p1 p3],{'��ʼλ��','ʵ�ʹ켣'},'Location','northeast');
clc;
figure('name','Input','position',[300 100 600 160]);
tiledlayout(1,1,'TileSpacing','none','Padding','none');
nexttile;
plot(ts(1:end-1), us(:,1),'-','LineWidth',2);
xlabel('$t(s)$','interpret','latex','fontsize',12);
ylabel('$F(N)$','interpret','latex','fontsize',12);
set(gca,'box','on','Xgrid','on','ygrid','on','xtick',0:3:sim_t);
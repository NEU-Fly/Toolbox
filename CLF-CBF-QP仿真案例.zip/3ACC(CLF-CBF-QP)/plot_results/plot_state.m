clc;
figure('Name','State','position',[300 100 600 200]);
tiledlayout(3,1,'TileSpacing','none','Padding','none');
nexttile;
plot(ts, xs(:,1),'-','LineWidth',2);
ylabel('$p(m)$','interpret','latex','fontsize',10);
set(gca,'box','on','Xgrid','on','ygrid','on','xtick',0:3:sim_t,'xticklabel',[],'ylim',[0 24],'ytick',0:12:24);

nexttile;
plot(ts, xs(:,2),'-','LineWidth',2);
ylabel('$v(m/s)$','interpret','latex','fontsize',10);
set(gca,'box','on','Xgrid','on','ygrid','on','xtick',0:3:sim_t,'xticklabel',[]);

nexttile;
plot(ts, xs(:,3),'-','LineWidth',2);
xlabel('$t(s)$','interpret','latex','fontsize',10);
ylabel('$z(m)$','interpret','latex','fontsize',10);
set(gca,'box','on','Xgrid','on','ygrid','on','xtick',0:3:sim_t);




figure('name','Result','position',[488,342,620,250]);
h=axes;
set(h,'position',[0,0.1,1,0.88],'NextPlot','add','ylim',[-2 2],'ytick',[],'ycolor','white');

% ��̬״̬�켣
te = text(h);
te1 = text(h);
te2 = text(h);
te3 = text(h);
te4 = text(h);
te5 = text(h);
set([te te1],'Color',[0 0.4470 0.7410],'FontSize',12);
set([te2 te3],'Color','r','FontSize',12);
set([te4 te5],'Color','k','FontSize',12);

w=0.5;
% ��
p4=rectangle(h,'Position',[xs(1,1)-w,-0.5*w,2*w,w],'LineWidth',2,'EdgeColor',[0 0.4470 0.7410],'FaceColor',[0 0.4470 0.7410]); 
% ǰ��
p5=rectangle(h,'Position',[xs(1,1)+xs(1,3)-w,-0.5*w,2*w,w],'LineWidth',2,'EdgeColor','red','FaceColor','red');
l1=0.35;
l2=0.15;
l3=0.25;
l11=line(h,[xs(1,1)-l1 xs(1,1)-l2],[l3 l3],'Color','k','LineStyle','-','LineWidth',6);
l22=line(h,[xs(1,1)+l1 xs(1,1)+l2],[l3 l3],'Color','k','LineStyle','-','LineWidth',6);
l33=line(h,[xs(1,1)-l1 xs(1,1)-l2],[-l3 -l3],'Color','k','LineStyle','-','LineWidth',6);
l44=line(h,[xs(1,1)+l1 xs(1,1)+l2],[-l3 -l3],'Color','k','LineStyle','-','LineWidth',6);

l55=line(h,[x0(3)-l1 x0(3)-l2],[l3 l3],'Color','k','LineStyle','-','LineWidth',6);
l66=line(h,[x0(3)+l1 x0(3)+l2],[l3 l3],'Color','k','LineStyle','-','LineWidth',6);
l77=line(h,[x0(3)-l1 x0(3)-l2],[-l3 -l3],'Color','k','LineStyle','-','LineWidth',6);
l88=line(h,[x0(3)+l1 x0(3)+l2],[-l3 -l3],'Color','k','LineStyle','-','LineWidth',6);
set(h,'xlim',[-1 x0(3)+4],'xtick',[-1:1:x0(3)+2]);
line1=line(h,[-1 x0(3)+2],[2 2],'color','black','linewidth',3);
line2=line(h,[-1 x0(3)+2],[-2 -2],'color','black','linewidth',3);
%%  
k=1; % �ӿ���ʾ�ٶ�
for i =1:k:size(xs(:,1),1)
    pause(0.015);
    pos = xs(i,1)+xs(i,3);% ǰ��λ��
    set(p4,'Position',[xs(i,1)-w,-0.5*w,2*w,w]);
    set(p5,'Position',[pos-w,-0.5*w,2*w,w]);
    set(l11,'XData',[xs(i,1)-l1 xs(i,1)-l2],'YData',[l3 l3]);
    set(l22,'XData',[xs(i,1)+l1 xs(i,1)+l2],'YData',[l3 l3]);
    set(l33,'XData',[xs(i,1)-l1 xs(i,1)-l2],'YData',[-l3 -l3]);
    set(l44,'XData',[xs(i,1)+l1 xs(i,1)+l2],'YData',[-l3 -l3]); 
    set(l55,'XData',[pos-l1 pos-l2],'YData',[l3 l3]);
    set(l66,'XData',[pos+l1 pos+l2],'YData',[l3 l3]);
    set(l77,'XData',[pos-l1 pos-l2],'YData',[-l3 -l3]);
    set(l88,'XData',[pos+l1 pos+l2],'YData',[-l3 -l3]); 
    set(h,'xlim',[pos-x0(3)-1 pos+2],'xtick',[ceil(pos)-x0(3)-1:1:ceil(pos)+2]);
   
    set(line1,'Xdata',[ceil(pos)-x0(3)-2 ceil(pos)+2],'Ydata',[2 2]);  
    set(line2,'Xdata',[ceil(pos)-x0(3)-2 ceil(pos)+2],'Ydata',[-2 -2]);
    
    set(te,'String',[' ����v_d :',num2str(params.vd),' m/s'],'position',[pos-x0(3)  1.7]);
    set(te1,'String',[' ʵ��v :',num2str(xs(i,2),'%0.2f\n'),' m/s'],'position',[pos-x0(3)+5  1.75]);
    set(te2,'String',[' ǰ��v_c :',num2str(params.v0),'m/s'],'position',[pos-x0(3)  1.2]);
    set(te3,'String',[' ����z :',num2str(xs(i,3),'%0.2f\n'),' m'],'position',[pos-x0(3)+5  1.25]);
    set(te4,'String',[' ʱ��t :',num2str(ts(i),'%0.0f\n'),' s'],'position',[pos-x0(3)  0.75]);
    set(te5,'String',[' ��ȫԼ�� z\geq',num2str(params.T*xs(i,2),'%0.2f\n'),' m'],'position',[pos-x0(3)+5  0.75]);

end

close all; clear all; clc;
addpath('plot_results');

dt = 0.02;
sim_t = 15;     
x0 = [0; 0; 10];  % �󳵳�ʼ״̬

params.v0 = 1;    % ǰ���ĳ��ٶ�
params.vd = 2;    % �������ٶ�
params.m  = 1650; % ������
params.g = 9.81;
params.f0 = 0.1;
params.f1 = 5;
params.f2 = 0.25;
params.ca = 0.3;
params.cd = 0.3;
params.T = 1.8;

params.u_max = params.ca * params.m * params.g;
params.u_min  = -params.cd * params.m * params.g;

params.clf.rate = 25;
params.cbf.rate = 5;


params.weight.input = 2/params.m^2;
params.weight.slack = 2e-2;

%%
accSys = ACC(params);

odeFun = @accSys.dynamics;
controller = @accSys.ctrlClfCbfQp;
odeSolver = @ode45;

total_k = ceil(sim_t / dt);
x = x0;
t = 0;   
% initialize traces.
xs = zeros(total_k, 3);
ts = zeros(total_k, 1);
us = zeros(total_k-1, 1);
slacks = zeros(total_k-1, 1);
hs = zeros(total_k-1, 1);
Vs = zeros(total_k-1, 1);
xs(1, :) = x0';
ts(1) = t;
for k = 1:total_k-1

    Fr = accSys.getFr(x);
    % Determine control input.
    [u, slack, h, V] = controller(x, Fr);        
    us(k, :) = u';
    slacks(k, :) = slack;
    hs(k) = h;
    Vs(k) = V;

    % Run one time step propagation.
    [ts_temp, xs_temp] = odeSolver(@(t, s) odeFun(t, s, u), [t t+dt], x);
    x = xs_temp(end, :)';

    xs(k+1, :) = x';
    ts(k+1) = ts_temp(end);
    t = t + dt;
	
    if mod(k,50) == 0
        clc;
       fprintf('��ǰ����ʱ�䣺%0.2f/%0.2f\n',t,sim_t);     
    end
end
                    
save data.mat;
%% ���ƽ��
% plot_state;
% plot_input;
draw_result;


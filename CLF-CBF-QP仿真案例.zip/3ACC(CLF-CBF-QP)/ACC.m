classdef ACC < CtrlAffineSys
    methods
        function obj = ACC(params)
            obj = obj@CtrlAffineSys(params);            
        end

        function Fr = getFr(obj, x)
            v = x(2);
            Fr = obj.params.f0 + obj.params.f1 * v + obj.params.f2 * v^2;
        end

        function [x, f, g] = defineSystem(~, params)
            syms p v z % states
            x = [p; v; z];

            f0 = params.f0;
            f1 = params.f1;
            f2 = params.f2;
            v0 = params.v0;
            m = params.m;
            Fr = f0 + f1 * v + f2 * v^2;

            % Dynamics
            f = [v; -Fr/m; v0-v];
            g = [0; 1/m; 0]; 
        end

        function clf = defineClf(obj, params, symbolic_state)
            v = symbolic_state(2);
            vd = params.vd; % desired velocity.           

            clf = 60*(v - vd)^2;
        end

        function cbf = defineCbf(obj, params, symbolic_state)
            v = symbolic_state(2);
            z = symbolic_state(3);

            v0 = params.v0;
            T = params.T;
            cd = params.cd;

            cbf = z - T * v - 0.5  * (v0-v)^2 / (cd * params.g);
        end
    end
end

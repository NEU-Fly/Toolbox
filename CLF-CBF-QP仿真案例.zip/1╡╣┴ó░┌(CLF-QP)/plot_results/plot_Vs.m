clc;
figure('name','Input','position',[300 200 600 150]);
tiledlayout(1,1,'TileSpacing','none','Padding','none');
nexttile;
plot(ts(1:end-1), Vs(:,1),'-','LineWidth',2);
xlabel('$t(s)$','interpret','latex','fontsize',10);
ylabel('$V$','interpret','latex','fontsize',10);
set(gca,'box','on','Xgrid','on','ygrid','on','xtick',0:2:sim_t);
figure('name','Result','position',[488,342,800,400]);
tiledlayout(2,2,'TileSpacing','none','Padding','none');

nexttile(1,[2 1]);
h1=gca;
axis equal;
set(h1,'LooseInset',get(h1,'TightInset'),'NextPlot','add','box','on',...
    'Xlim',[-2, 1],'Ylim',[-1, 2],'Xtick',-2:1:1,'Ytick',-1:1:2);
xlabel(h1,'$x(m)$','interpret','latex','fontsize',12)
ylabel(h1,'$y(m)$','interpret','latex','fontsize',12)
plot(h1,[-2 2],[-0.7 -0.7],'k-','Linewidth',2);
title('����������');
% С��
h1rec=rectangle(h1,'Position',[xs(1,1)-0.5,-0.5,1,0.5],...
           'LineWidth',2,'EdgeColor','b','FaceColor','b'); % ����
h1l1=plot(h1,x(1,1)-0.25,-0.6,'o','markersize',16,'MarkerEdgeColor','k','MarkerFaceColor','k'); % ����
h1l2=plot(h1,x(1,1)+0.25,-0.6,'o','markersize',16,'MarkerEdgeColor','k','MarkerFaceColor','k'); % ����
h1l3=line(h1,[0 0],[0 1],'LineStyle','-');  % ����
h1l4=line(h1,0,0,'Marker','.','LineWidth',4,'color',[0.8500 0.3250 0.0980]); % ľ��
h1l5=line(h1,0,0,'color','k','Marker','.', 'MarkerSize', 25); % ���ӵ�
% ��̬״̬�켣
text1 = text(h1);
text2 = text(h1);
set(text1,'Color','red','Position',[-1.2 1.5],'FontSize',15);
set(text2,'Color','red','Position',[-0.3 1.532],'FontSize',15);
% ����
for i= -1.8:0.2:1   
    plot(h1,[i,i-0.2],[-0.7 -0.9],'-k','linewidth',1);  
end


nexttile(4);
plot(ts(1), Vs(1,1),'b.');
title('CLF');
xlabel('$t(s)$','interpret','latex','fontsize',12);
ylabel('$V$','interpret','latex','fontsize',12);
set(gca,'ylim',[0 30],'xlim',[0 sim_t],'xtick',[0:2:sim_t],'box','on','Xgrid','on','ygrid','on');

nexttile(2);
plot(ts(1), xs(1,3)*180/pi,'b.');
title('�Ƕ�\theta');
xlabel('$t(s)$','interpret','latex','fontsize',12);
ylabel('$\theta(^o)$','interpret','latex','fontsize',12);
set(gca,'ylim',[-10 30],'xlim',[0 sim_t],'xtick',[0:2:sim_t],'box','on','xgrid','on','ygrid','on');

myvideo = VideoWriter('.\������1.avi');   % ������һ��avi�ļ�
myvideo.FrameRate = 30;                % ����֡Ƶ��
open(myvideo);                         % ��ʱƵ

for i = 1:2:size(xs(:,1))-1
    % ����
    theta = xs(i,3); 
    R = [cos(theta) -sin(theta); 
         sin(theta)  cos(theta)];
    xr=R*[0;1]+[xs(i,1);0];
    set(text1,'String',['T = ',num2str(ts(i),'%0.0f\n'),'s']);
    set(text2,'String',['\theta = ',num2str(180*theta/pi,'%.1f\n'),'^��']);
    set(text1,'String',['T: ',num2str(ts(i),'%0.0f\n'),'s']);
    set(h1rec,'position',[xs(i,1)-0.5,-0.5,1,0.5]);
    set(h1l1,'XData',xs(i,1)-0.25,'YData',-0.6);
    set(h1l2,'XData',xs(i,1)+0.25,'YData',-0.6);
    set(h1l3,'XData',[xs(i,1) xs(i,1)],'YData',[0 1]);
    set(h1l4,'XData',[xs(i,1) xr(1)],'YData',[0 xr(2)]);
    set(h1l5,'XData',xs(i,1),'YData',0);

    nexttile(4);
    % CLF
    hold on
    plot(gca,ts(1:i), Vs(1:i,1),'b-','linewidth',2);
    hold off

    nexttile(2);
    % �Ƕ�
    hold on
    plot(gca,ts(1:i), xs(1:i,3)*180/pi,'b-','linewidth',2);
    hold off
   
    % ������Ƶ
    drawnow limitrate                   % ���ٻ���
    frame = getframe(gcf);              % ץȡ��ͼ����ͼƬ
    im = frame2im(frame);               % ת����ʽ
    writeVideo(myvideo,im);             % д����Ƶ��
end
    close(myvideo);                     % �ر�avi�ļ�
    
% legend([p1 p2 p4],{'��ʼλ��','Ŀ��λ��','ʵ�ʹ켣'},'Location','northwest');

figure('name','������','position',[488,342,400,400]);
h=axes();

axis equal;
set(h,'LooseInset',get(h,'TightInset'),'NextPlot','add','box','on',...
    'Xlim',[-2, 1],'Ylim',[-1, 2],'Xtick',-2:1:1,'Ytick',-1:1:2);
xlabel(h,'$x(m)$','interpret','latex','fontsize',12)
ylabel(h,'$y(m)$','interpret','latex','fontsize',12)

plot(h,[-2 2],[-0.7 -0.7],'k-','Linewidth',2);
% С��
rec=rectangle(h,'Position',[xs(1,1)-0.5,-0.5,1,0.5],...
           'LineWidth',2,'EdgeColor','#0070C0','FaceColor','#0070C0'); % ����
l1=plot(h,x(1,1)-0.25,-0.6,'o','markersize',16,'MarkerEdgeColor','k','MarkerFaceColor','k'); % ����
l2=plot(h,x(1,1)+0.25,-0.6,'o','markersize',16,'MarkerEdgeColor','k','MarkerFaceColor','k'); % ����
l3=line(h,[0 0],[0 1],'LineStyle','--');  % ����
l4=line(h,0,0,'Marker','.','LineWidth',4,'color','#C00000'); % ľ��
l5=line(h,0,0,'color','k','Marker','.', 'MarkerSize', 25); % ���ӵ�
%%
% ��̬״̬�켣
% text1 = text(h);
text2 = text(h);
% set(text1,'Color','red','Position',[-1.2 1.5],'FontSize',15);
set(text2,'Color','k','Position',[-0.3 1.532],'FontSize',15);

 for i= -1.8:0.2:1   
    plot(h,[i,i-0.2],[-0.7 -0.9],'-k','linewidth',1);  
 end


k=4; % �ӿ���ʾ�ٶ�
for i = 1:k:size(xs(:,1))
    pause(0.04);
    theta = xs(i,3); 
    R = [cos(theta) -sin(theta); 
         sin(theta)  cos(theta)];
    xr=R*[0;1]+[xs(i,1);0];

%     set(text1,'String',['T = ',num2str(ts(i),'%0.0f\n'),'s']);
    set(text2,'String',['\theta = ',num2str(180*theta/pi,'%.1f\n'),'^��']);

%     set(text1,'String',['T: ',num2str(ts(i),'%0.0f\n'),'s']);
    set(rec,'position',[xs(i,1)-0.5,-0.5,1,0.5]);
    set(l1,'XData',xs(i,1)-0.25,'YData',-0.6);
    set(l2,'XData',xs(i,1)+0.25,'YData',-0.6);
    set(l3,'XData',[xs(i,1) xs(i,1)],'YData',[0 1]);
    set(l4,'XData',[xs(i,1) xr(1)],'YData',[0 xr(2)]);
    set(l5,'XData',xs(i,1),'YData',0);
end
% legend([p1 p2 p4],{'��ʼλ��','Ŀ��λ��','ʵ�ʹ켣'},'Location','northwest');

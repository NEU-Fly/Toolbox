clc;
figure('name','State','position',[300 150 600 300]);
tiledlayout(4,1,'TileSpacing','none','Padding','none');

nexttile;
plot(ts, xs(:,1),'-','LineWidth',2);
ylabel('$x(m)$','interpret','latex','fontsize',10);
set(gca,'xtick',[0:2:sim_t],'box','on','Xgrid','on','ygrid','on','xticklabel',[],'yTickLabel',num2str(get(gca,'yTick')','%.1f'));

nexttile;
plot(ts, xs(:,2),'-','LineWidth',2);
ylabel('$v_x(m/s)$','interpret','latex','fontsize',10);
set(gca,'xtick',[0:2:sim_t],'box','on','Xgrid','on','ygrid','on','xticklabel',[],'yTickLabel',num2str(get(gca,'yTick')','%.1f'));

nexttile;
plot(ts, xs(:,3).*180/(pi),'-','LineWidth',2);
ylabel('$\theta(^o)$','interpret','latex','fontsize',10);
set(gca,'ylim',[-10 30],'xtick',[0:2:sim_t],'box','on','Xgrid','on','ygrid','on','xticklabel',[]);

nexttile;
plot(ts, xs(:, 4),'-','LineWidth',2);
xlabel('$t(s)$','interpret','latex','fontsize',10);
ylabel('$\dot{\theta}(rad/s)$','interpret','latex','fontsize',10);
set(gca,'xtick',[0:2:sim_t],'box','on','Xgrid','on','ygrid','on','yTickLabel',num2str(get(gca,'yTick')','%.1f'));
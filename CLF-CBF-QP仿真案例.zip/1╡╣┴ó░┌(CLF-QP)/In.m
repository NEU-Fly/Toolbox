classdef In < CtrlAffineSys
methods
    function [x, f, g] = defineSystem(~, ~)
        syms p_x v_x theta omega;  % �������״̬����
        x = [p_x; v_x; theta; omega];

        A = [0     1      0   0;
             0 -0.0883 0.6293 0;
             0     0      0   1;
             0  -0.236  27.57 0];
        B = [0; 0.865; 0; 2.357];

        f = A * x;
        g = B;
    end
    
    function clf = defineClf(~, params, symbolic_state)
        x = symbolic_state;

        A = [0     1      0   0;
             0 -0.0883 0.6293 0;
             0     0      0   1;
             0  -0.236  27.57 0];
        B = [0; 0.865; 0; 2.357];
        
        Q = eye(size(A));
        R = eye(size(B,2));
        [~,P] = lqr(A,B,Q,R);

        e = x;
        clf = e' * P * e;        
    end
    
    function cbf = defineCbf(~, params, symbolic_state)
        cbf = [];
    end 
end
end

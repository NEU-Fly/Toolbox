function [U, B, feas] = ctrlCbfQp(obj, x, u_ref)  
    if nargin < 3
        u_ref = zeros(obj.udim, 1);
    end

    Belta = obj.params.cbf.rate;
    Umin = obj.params.u_min;
    Umax = obj.params.u_max;
      
    B = obj.cbf(x);
    LfB = obj.lf_cbf(x);
    LgB = obj.lg_cbf(x);        
   
   %% QP���
    u = sdpvar(obj.udim,1); % ���߱���
   %% Լ��  
    Constraints = [];
    % CBFԼ��
    Constraints = [Constraints; LfB + LgB*u + Belta*B >= 0];  
    % ��������Լ��
    Constraints = [Constraints; Umin <= u; u <= Umax];
    %% �ɱ�����
    H = obj.params.weight.input * eye(obj.udim);
    Objective = 0.5*((u-u_ref)'*H*(u-u_ref));
    Options = sdpsettings('verbose',0,'solver','quadprog');
    sol = solvesdp(Constraints,Objective,Options);

    if sol.problem == 0
        U = value(u);
        feas = 1;
    else
        feas = 0;           
        disp('QP���ɽ�');
    end          
end
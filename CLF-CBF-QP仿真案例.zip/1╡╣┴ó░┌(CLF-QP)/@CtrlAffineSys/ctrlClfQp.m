function [U, V, slack, feas] = ctrlClfQp(obj, x, u_ref)
    if nargin < 3
        u_ref = zeros(obj.udim, 1);
    end

    Alpha = obj.params.clf.rate;
    Umin = obj.params.u_min;
    Umax = obj.params.u_max;
    Slack = obj.params.weight.slack;
    
    V = obj.clf(x);
    LfV = obj.lf_clf(x);
    LgV = obj.lg_clf(x); 
   %% QP���
    u = sdpvar(obj.udim,1); % ���߱���
    delta = sdpvar(1,1);
   %% Լ��  
    Constraints = [];
    % CLFԼ��
    Constraints = [Constraints; LfV + LgV*u + Alpha*V <= delta];  
    % ��������Լ��
    Constraints = [Constraints; Umin <= u; u <= Umax];
    %% �ɱ�����
    H = obj.params.weight.input * eye(obj.udim);
    Objective = 0.5*((u-u_ref)'*H*(u-u_ref)) + Slack*delta^2;
    Options = sdpsettings('verbose',0,'solver','quadprog');
    sol = solvesdp(Constraints,Objective,Options);

    if sol.problem == 0
        U = value(u);
        slack = value(delta);
        feas = 1;
    else
        feas = 0;           
        disp('QP���ɽ�');
    end          
end